package com.jabirdeveloper.tinderswipe;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;

public class TrophyRoom extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_trophy_room);
    }
    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void shareClick2(View view){
        ImageButton BtnNext = view.findViewById(R.id.Btn_btn);
        BtnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "https://valor.globo.com/brasil/noticia/2021/06/23/nova-variante-de-covid-19-e-encontrada-no-estado-do-rj.ghtml");
                sendIntent.setType("text/plain");
                startActivity(sendIntent);

            }
        });
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void shareClick3(View view){
        ImageButton BtnNext = view.findViewById(R.id.Btn_btn2);
        BtnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sendIntent = new Intent();
                sendIntent.setAction(Intent.ACTION_SEND);
                sendIntent.putExtra(Intent.EXTRA_TEXT, "https://valor.globo.com/mundo/noticia/2021/06/25/autoridades-bloqueiam-partes-de-sydney-para-conter-avanco-da-variante-delta-da-covid-19.ghtml");
                sendIntent.setType("text/plain");
                startActivity(sendIntent);

            }
        });
    }
}