package com.jabirdeveloper.tinderswipe;

import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.DiffUtil;

import android.app.Activity;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.animation.LinearInterpolator;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import com.yuyakaido.android.cardstackview.CardStackLayoutManager;
import com.yuyakaido.android.cardstackview.CardStackListener;
import com.yuyakaido.android.cardstackview.CardStackView;
import com.yuyakaido.android.cardstackview.Direction;
import com.yuyakaido.android.cardstackview.StackFrom;
import com.yuyakaido.android.cardstackview.SwipeableMethod;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private CardStackLayoutManager manager;
    private CardStackAdapter adapter;
    private Activity mView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        CardStackView cardStackView = findViewById(R.id.card_stack_view);
        manager = new CardStackLayoutManager(this, new CardStackListener() {
            @Override
            public void onCardDragging(Direction direction, float ratio) {
                Log.d(TAG, "onCardDragging: d=" + direction.name() + " ratio=" + ratio);
            }

            @Override
            public void onCardSwiped(Direction direction) {
                Log.d(TAG, "onCardSwiped: p=" + manager.getTopPosition() + " d=" + direction);
                if (direction == Direction.Right){
                    Toast.makeText(MainActivity.this, "Real News", Toast.LENGTH_SHORT).show();
                }/*
                if (direction == Direction.Top){
                    Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();
                }*/
                if (direction == Direction.Left){
                    Toast.makeText(MainActivity.this, "Fake News", Toast.LENGTH_SHORT).show();
                }/*
                if (direction == Direction.Bottom){
                    Toast.makeText(MainActivity.this, "", Toast.LENGTH_SHORT).show();
                }*/

                // Paginating
                if (manager.getTopPosition() == adapter.getItemCount() - 5){
                    paginate();
                }

            }

            @Override
            public void onCardRewound() {
                Log.d(TAG, "onCardRewound: " + manager.getTopPosition());
            }

            @Override
            public void onCardCanceled() {
                Log.d(TAG, "onCardRewound: " + manager.getTopPosition());
            }

            @Override
            public void onCardAppeared(View view, int position) {
                TextView tv = view.findViewById(R.id.item_name);
                Log.d(TAG, "onCardAppeared: " + position + ", name: " + tv.getText());
            }

            @Override
            public void onCardDisappeared(View view, int position) {
                TextView tv = view.findViewById(R.id.item_name);
                Log.d(TAG, "onCardAppeared: " + position + ", name: " + tv.getText());
            }
        });
        manager.setStackFrom(StackFrom.None);
        manager.setVisibleCount(3);
        manager.setTranslationInterval(8.0f);
        manager.setScaleInterval(0.95f);
        manager.setSwipeThreshold(0.3f);
        manager.setMaxDegree(20.0f);
        manager.setDirections(Direction.FREEDOM);
        manager.setCanScrollHorizontal(true);
        manager.setSwipeableMethod(SwipeableMethod.Manual);
        manager.setOverlayInterpolator(new LinearInterpolator());
        adapter = new CardStackAdapter(addList());
        cardStackView.setLayoutManager(manager);
        cardStackView.setAdapter(adapter);
        cardStackView.setItemAnimator(new DefaultItemAnimator());

    }


    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void trophyClick(View view){
        ImageButton BtnNext = view.findViewById(R.id.Btn_trophy);
        BtnNext.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent it3 = new Intent(MainActivity.this, TrophyRoom.class);
                startActivity(it3);

            }
        });
    }

    private void paginate() {
        List<ItemModel> old = adapter.getItems();
        List<ItemModel> newly = new ArrayList<>(addList());
        CardStackCallback callback = new CardStackCallback(old, newly);
        DiffUtil.DiffResult result = DiffUtil.calculateDiff(callback);
        adapter.setItems(newly);
        result.dispatchUpdatesTo(adapter);
    }

    private List<ItemModel> addList() {
        List<ItemModel> items = new ArrayList<>();
        items.add(new ItemModel(R.drawable.verdadeira2, "Covid Variant", "2021", "Rio de Janeiro"));
        items.add(new ItemModel(R.drawable.falsa1, "Covid", "2020", "Amazonas"));
        items.add(new ItemModel(R.drawable.falsa2, "Vaccine", "2020", "UK"));
        items.add(new ItemModel(R.drawable.verdadeira1, "Covid", "2021", "Sydney"));


        items.add(new ItemModel(R.drawable.ultima1, "", "", ""));
        items.add(new ItemModel(R.drawable.ultima1, "", "", ""));
        items.add(new ItemModel(R.drawable.ultima1, "", "", ""));
        items.add(new ItemModel(R.drawable.ultima1, "", "", ""));
        items.add(new ItemModel(R.drawable.ultima1, "", "", ""));

        return items;
    }

}
